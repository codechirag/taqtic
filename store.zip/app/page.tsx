import QAComplianceForm from "../components/qa-compliance-form"

export default function Page() {
  return <QAComplianceForm />
}
